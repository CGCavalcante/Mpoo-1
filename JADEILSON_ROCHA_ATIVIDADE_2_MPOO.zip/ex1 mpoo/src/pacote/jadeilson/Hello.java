package pacote.jadeilson;
public class Hello {

	private String Nome;
	private static int ObjetosCriados = 0;
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public void imprimir() {
		DataHora data = new DataHora();
		System.out.println(data.getData() + " - Ol� " + this.getNome()
				+ ". Voc� acabou de fazer seu primeiro Hello World em Java. Parab�ns.");
	}
	public Hello(){
		ObjetosCriados++;
	}
	public static void numDeObjCriados(){
		DataHora data = new DataHora();
		System.out.println("O numero total de objeto(s) criado(s) foi de: " + ObjetosCriados + " �s " + data.getData() + "Hs!!!");
	}

}