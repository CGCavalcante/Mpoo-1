package pacote.jadeilson;
import java.util.Scanner;

public class Application {
	public static void main(String[] args) {
		 
		Hello h1 = new Hello();
		h1.setNome("gabriel");
		h1.imprimir();
		Hello h3 = new Hello();
		h3.setNome("Jadeilson");
		h3.imprimir();
		Hello h2 = new Hello();
		Hello h4 = new Hello();
		h2.imprimir();
		h4.setNome("Gabriel Alves");
		h4.imprimir();
		Hello.numDeObjCriados();		
	}
}
	