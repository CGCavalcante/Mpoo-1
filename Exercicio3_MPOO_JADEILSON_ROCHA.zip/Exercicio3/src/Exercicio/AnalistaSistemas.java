package Exercicio;

public class AnalistaSistemas extends Funcionario {
	private String Tipo;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	public void imprimir() { 
        System.out.println(this.getNome() + " � um(a) Analista de Sistemas, ganha " +
          this.getSalario() + "R$ e tem um custo de " +
          this.getCusto() + "R$!!! Seu cargo � de Analista " + this.getTipo());
    }
}
