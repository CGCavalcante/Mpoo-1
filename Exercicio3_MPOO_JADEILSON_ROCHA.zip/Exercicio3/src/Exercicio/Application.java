package Exercicio;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Programador Paulo = new Programador();
		Gerente Daniel = new Gerente();
		Secretaria Joyce = new Secretaria();
		AnalistaSistemas Pedro = new AnalistaSistemas();		
		Paulo.setNome("Paulo");
		Paulo.setSalario(1000);
		Paulo.lista.add("Paulo");
		Paulo.setFuncao("Desenvolver Jogos");
		Paulo.imprimir();
		Daniel.setNome("Daniel");
		Daniel.setSalario(2200);
		Daniel.setArea("Comercial");
		Daniel.lista.add("Daniel");
		Daniel.imprimir();
		Joyce.setNome("Joyce");
		Joyce.setSalario(1000);
		Joyce.setLider("Analista de Sistemas");
		Joyce.lista.add("Joyce");
		Joyce.imprimir();
		Pedro.setNome("Pedro");
		Pedro.setSalario(2000);
		Pedro.setTipo("Pleno");
		Pedro.lista.add("Pedro");
		Pedro.imprimir();
		Pedro.imprimirLista();
		
	}

}
