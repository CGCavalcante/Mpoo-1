package Exercicio;

public class Secretaria extends Funcionario{
	private String Lider;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public String getLider() {
		return Lider;
	}
	public void setLider(String lider) {
		Lider = lider;
	}
	public void imprimir() { 
        System.out.println(this.getNome() + " � um(a) Secretaria(o), ganha " +
          this.getSalario() + "R$ e tem um custo de " +
          this.getCusto() + "R$!!! Seu l�der �: " + this.getLider());
    }
}
