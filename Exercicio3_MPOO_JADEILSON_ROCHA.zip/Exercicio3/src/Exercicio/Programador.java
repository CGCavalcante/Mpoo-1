package Exercicio;

public class Programador extends Funcionario {
	private String Funcao;
	public String getFuncao() {
		return Funcao;
	}
	public void setFuncao(String funcao) {
		Funcao = funcao;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void imprimir() { 
        System.out.println(this.getNome() + " � um programador, ganha " +
          this.getSalario() + "R$ e tem um custo de " +
          this.getCusto() + "R$!!! Sua fun��o �: " + this.getFuncao());
    }

}
