package Exercicio;

public class Gerente extends Funcionario{
	private String Area;
	public String getArea() {
		return Area;
	}
	public void setArea(String area) {
		Area = area;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void imprimir() { 
        System.out.println(this.getNome() + " � um(a) Gerente, ganha " +
          this.getSalario() + "R$ e tem um custo de " +
          this.getCusto() + "R$!!! Sua �rea �: " + this.getArea());
    }

}
