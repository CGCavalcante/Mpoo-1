package Exercicio;
import java.util.ArrayList;

public class Funcionario {
	public static ArrayList<String> lista = new ArrayList<String>();
	private static final double PERCENTUAL_CUSTO = 1.8;
	private String nome;
	private double salario;
	private double custo;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
		this.custo = salario * PERCENTUAL_CUSTO;
	}
	public double getCusto() {
		return custo;
	}
	public ArrayList getLista() {
		return lista;
	}
	public void setLista(ArrayList lista) {
		this.lista = lista;
	}
	public void imprimir() { 
		String salario = String.format("%.2f", this.getSalario());
		String custo = String.format("%.2f", this.getCusto());
        System.out.println(this.getNome() + " � um funcionario e ganha R$"+ salario +  
          " e tem um custo de R$" + custo+"\n"); 
    }
	public void imprimir(String cabecalho, String rodape) { 
		String salario = String.format("%.2f", this.getSalario());
		String custo = String.format("%.2f", this.getCusto());
        System.out.println("Cabe�alho: "+cabecalho +"\n"+ this.getNome() + " � um funcionario e ganha R$"+ salario +  
          " e tem um custo de R$" + custo +"\n" +"Rodap�: "+ rodape+"\n");
	}
	public void imprimir(String cabecalho) { 
		String salario = String.format("%.2f", this.getSalario());
		String custo = String.format("%.2f", this.getCusto());
        System.out.println("Cabe�alho: "+cabecalho +"\n"+this.getNome() + " � um funcionario e ganha R$"+ salario +  
          " e tem um custo de R$" + custo+"\n");
    }
	public void imprimir(char cabecalho, String rodape) { 
		String salario = String.format("%.2f", this.getSalario());
		String custo = String.format("%.2f", this.getCusto());
        System.out.println(this.getNome() + " � um funcionario e ganha R$"+ salario +  
          " e tem um custo de R$" + custo + "\n" +"Rodap�: "+ rodape +"\n");
	}
	
	public void imprimirLista(){
		System.out.println("Listagem de Todos os Funcion�rios da empresa: " + this.getLista()+"\n");
	}
	public void aumento(float aumentar){
		float aumentoSalario = (float) (this.getSalario()*(aumentar/100));
		this.setSalario(this.getSalario() + aumentoSalario);
	}
	public void aumento(){
		float aumentoSalario = (float) (this.getSalario()*0.1);
		this.setSalario(this.getSalario() + aumentoSalario);
	}
}