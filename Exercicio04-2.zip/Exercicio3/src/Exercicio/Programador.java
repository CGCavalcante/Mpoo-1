package Exercicio;

public class Programador extends Funcionario {
	private String Funcao = "Programador";
	public String getFuncao() {
		return Funcao;
	}
	public void setFuncao(String funcao) {
		Funcao = funcao;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	

}
