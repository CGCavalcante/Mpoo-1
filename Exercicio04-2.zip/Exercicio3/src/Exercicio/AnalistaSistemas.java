package Exercicio;

public class AnalistaSistemas extends Funcionario {
	private String Tipo= "Analista Pleno";
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	
}
