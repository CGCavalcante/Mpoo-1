package Exercicio;

public class Gerente extends Funcionario{
	private String Area = "Gerente";
	public String getArea() {
		return Area;
	}
	public void setArea(String area) {
		Area = area;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	

}
