package Exercicio;

public class Secretaria extends Funcionario{
	private String Lider = "Gerente";
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public String getLider() {
		return Lider;
	}
	public void setLider(String lider) {
		Lider = lider;
	}
	
}
