package pacote.jadeilson;
public class Hello {

	private String Nome;

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public void imprimir() {
		DataHora data = new DataHora();
		System.out.println(data.getData() + " - Ol� " + this.getNome()
				+ ". Voc� acabou de fazer seu primeiro Hello World em Java. Parab�ns.");

	}

}
