package pacote.jadeilson;

public class Application {

	public static void main(String[] args) {
		Hello h1 = new Hello();
		h1.setNome("gabriel");
		h1.imprimir();
		Hello h3 = new Hello();
		h3.setNome("Jadeilson");
		h3.imprimir();
		Hello h2 = new Hello();
		h2.imprimir();
	}
}
