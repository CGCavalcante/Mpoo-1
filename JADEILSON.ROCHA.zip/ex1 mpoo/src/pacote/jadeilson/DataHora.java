package pacote.jadeilson;
import java.util.*;
import java.text.SimpleDateFormat;

public class DataHora {

	public String getData() {
		SimpleDateFormat formato = new SimpleDateFormat("HH:mm:ss");
		Date data = new Date();
		String datas = formato.format(data);
		return (datas);

	}

	public static void main(String[] args) {
		DataHora hora = new DataHora();
		System.out.println(hora.getData());
	}
}
